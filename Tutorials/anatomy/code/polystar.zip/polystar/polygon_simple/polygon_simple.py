def setup():
    size(300, 300)
    background(255)
    smooth()
  
    noFill()
    polygon(3, 50, 75, 50)
    polygon(4, 170, 75, 50)
  
    fill(255, 204, 255)
    stroke(128, 0, 128)
    polygon(5, 50, 180, 50)
  
    noFill()
    stroke(0)
    polygon(6, 170, 180, 50)

def polygon(n, cx, cy, r):
    angle = 360.0 / n
  
    beginShape();
    for i in xrange(n):
        vertex(cx + r * cos(radians(angle * i)),
          cy + r * sin(radians(angle * i)))
    endShape(CLOSE)