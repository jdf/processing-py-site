def setup():
    size(300, 300)
    background(255)
    smooth()
    
    noFill()
    polygon(3, 70, 75, 50)   # use the defaults
    polygon(4, 170, 75, 25)
    
    stroke(128)
    # draw enclosing ellipses to make sure we did it right
    ellipse(70, 75, 100, 100)
    ellipse(170, 75, 50, 50)

def polygon(n, cx, cy, r, h = None, startAngle = None):
    if (h == None and startAngle == None): # User defined 4 parameters
        # If not, adjust our parameters.
        w = r * 2.0
        h = r * 2.0
        startAngle = 0
    else: # User defined 6 parameters
        w = r
        
    angle = TWO_PI/ n
    
    # The "radius" is one half the total width and height
    w = w / 2.0
    h = h / 2.0
    
    beginShape()
    for i in xrange(n):
        vertex(cx + w * cos(startAngle + angle * i),
          cy + h * sin(startAngle + angle * i))
    endShape(CLOSE)
