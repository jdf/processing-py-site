def setup():
    size(300, 300)
    background(255)
    frameRate(6)
    smooth()
    rectMode(CENTER)

def draw():
    # choose a random stroke color
    r = int(random(0, 255))
    g = int(random(0, 255))
    b = int(random(0, 255))
    # and fill opacity
    opacity = int(random(100, 255))
    nSides = int(random(3, 9))
    
    # determine the center x and y coordinates
    cx = 25 + 50 * int(random(0, 6))
    cy = 25 + 50 * int(random(0, 6))
    
    # if a random number (0 or 1) is 0, draw a polygon;
    # otherwise, draw a star
    isPolygon = int(random(2)) == 0
    
    
    # for stars, you need the proportion of short to long radius

    stroke(255)   # erase any previous drawing in this area
    fill(255)
    rect(cx, cy, 50, 50)
      
    stroke(r, g, b)
    fill(r, g, b, opacity)
    if (isPolygon):
        polygon(nSides, cx, cy, 24)
    else:
        prop = random(0.2, 0.8) * cos(PI / nSides)
        star(nSides, cx, cy, 24, proportion = prop)


def polygon(n, cx, cy, r, h = None, startAngle = None):
    if (h == None and startAngle == None): # User defined 4 parameters
        # If not, adjust our parameters.
        w = r * 2.0
        h = r * 2.0
        startAngle = 0
    else: # User defined 6 parameters
        w = r
        
    angle = TWO_PI/ n
    
    # The "radius" is one half the total width and height
    w = w / 2.0
    h = h / 2.0
    
    beginShape()
    for i in xrange(n):
        vertex(cx + w * cos(startAngle + angle * i),
          cy + h * sin(startAngle + angle * i))
    endShape(CLOSE)

def star(n, cx, cy, r, h = None, startAngle = None, proportion = 1.0):
    if (h == None and startAngle == None): # User defined 4 parameters
        # If not, adjust our parameters.
        w = r * 2.0
        h = r * 2.0
        startAngle = 0
    else: # User defined 6 parameters
        w = r

    if (n > 2):
        angle = TWO_PI/ (2*n)   # twice as many sides
        dw = 0  # draw width
        dh = 0  # draw height
        
        w = w / 2.0
        h = h / 2.0
        
        beginShape()
        for i in xrange(2 * n):
            print dw, w, h, dh
            dw = w
            dh = h
            if (i % 2 == 1): # for odd vertices, use short radius
              dw = w * proportion
              dh = h * proportion
            vertex(cx + dw * cos(startAngle + angle * i),
              cy + dh * sin(startAngle + angle * i))
        endShape(CLOSE)

